// Datos de películas (simulando una base de datos)
const peliculas = [
    {
        id: 1,
        titulo: "El Padrino",
        año: 1972,
        genero: "Drama/Crimen",
        descripcion: "La saga de la familia Corleone, liderada por Vito Corleone y posteriormente por su hijo Michael, en el mundo del crimen organizado.",
        poster: "https://via.placeholder.com/300x450?text=El+Padrino",
        calificacion: 0
    },
    {
        id: 2,
        titulo: "Pulp Fiction",
        año: 1994,
        genero: "Crimen/Drama",
        descripcion: "Las vidas de dos mafiosos, un boxeador, la esposa de un gánster y un par de bandidos se entrelazan en cuatro historias de violencia y redención.",
        poster: "https://via.placeholder.com/300x450?text=Pulp+Fiction",
        calificacion: 0
    },
    {
        id: 3,
        titulo: "El Caballero de la Noche",
        año: 2008,
        genero: "Acción/Crimen",
        descripcion: "Batman tiene que enfrentarse a un nuevo criminal, el Joker, que sume a Ciudad Gótica en el caos.",
        poster: "https://via.placeholder.com/300x450?text=El+Caballero+de+la+Noche",
        calificacion: 0
    },
    {
        id: 4,
        titulo: "Forrest Gump",
        año: 1994,
        genero: "Drama/Romance",
        descripcion: "La vida de Forrest Gump, un hombre con un coeficiente intelectual bajo pero con un gran corazón, que presencia y participa en muchos de los eventos más importantes de la historia de EE.UU.",
        poster: "https://via.placeholder.com/300x450?text=Forrest+Gump",
        calificacion: 0
    },
    {
        id: 5,
        titulo: "Inception",
        año: 2010,
        genero: "Ciencia ficción/Acción",
        descripcion: "Un ladrón que roba secretos a través del uso de tecnología para compartir sueños es encargado de la misión inversa: implantar una idea en la mente de un objetivo.",
        poster: "https://via.placeholder.com/300x450?text=Inception",
        calificacion: 0
    },
    {
        id: 6,
        titulo: "La Lista de Schindler",
        año: 1993,
        genero: "Drama/Histórico",
        descripcion: "En la Polonia ocupada por los alemanes durante la Segunda Guerra Mundial, Oskar Schindler se preocupa por sus trabajadores judíos después de ser testigo de su persecución por los nazis.",
        poster: "https://via.placeholder.com/300x450?text=La+Lista+de+Schindler",
        calificacion: 0
    }
];

// ==================
// MODAL DE DETALLES
// ==================

// Variables globales
let peliculaActual = null;
let calificacionSeleccionada = 0;

// Elementos del DOM
const peliculasContainer = document.getElementById('peliculas-container');
const modal = document.getElementById('modal');
const closeModal = document.getElementById('close-modal');
const modalTitle = document.getElementById('modal-title');
const modalYear = document.getElementById('modal-year');
const modalGenre = document.getElementById('modal-genre');
const modalDesc = document.getElementById('modal-desc');
const modalPoster = document.getElementById('modal-poster');
const starsContainer = document.getElementById('stars-container');
const submitRating = document.getElementById('submit-rating');

// Cargar películas al iniciar
document.addEventListener('DOMContentLoaded', () => {
    cargarPeliculas();
    
    // Event listeners
    closeModal.addEventListener('click', cerrarModal);
    submitRating.addEventListener('click', guardarCalificacion);
});

// Función para cargar las películas en el grid
function cargarPeliculas() {
    peliculasContainer.innerHTML = '';
    
    peliculas.forEach(pelicula => {
        const peliculaCard = document.createElement('div');
        peliculaCard.className = 'pelicula-card';
        peliculaCard.dataset.id = pelicula.id;
        
        peliculaCard.innerHTML = `
            <div class="pelicula-poster">
                <img src="${pelicula.poster}" alt="${pelicula.titulo}">
            </div>
            <div class="pelicula-info">
                <h3>${pelicula.titulo}</h3>
                <p>${pelicula.año} • ${pelicula.genero}</p>
            </div>
        `;
        
        peliculaCard.addEventListener('click', () => abrirModal(pelicula.id));
        peliculasContainer.appendChild(peliculaCard);
    });
}

// Abre el modal con los detalles de la película seleccionada
function abrirModal(id) {
    peliculaActual = peliculas.find(p => p.id === id);
    
    if (!peliculaActual) return;
    
    modalTitle.textContent = peliculaActual.titulo;
    modalYear.textContent = `Año: ${peliculaActual.año}`;
    modalGenre.textContent = `Género: ${peliculaActual.genero}`;
    modalDesc.textContent = peliculaActual.descripcion;
    modalPoster.innerHTML = `<img src="${peliculaActual.poster}" alt="${peliculaActual.titulo}">`;
    
    // Cargar estrellas de calificación
    cargarEstrellas();
    
    modal.style.display = 'block';
    document.body.style.overflow = 'hidden';
}

// Cierra el modal
function cerrarModal() {
    modal.style.display = 'none';
    document.body.style.overflow = 'auto';
    peliculaActual = null;
    calificacionSeleccionada = 0;
}

// ==================
// CALIFICACIÓN CON ESTRELLAS
// ==================

// Resalta las estrellas al pasar el mouse
function resaltarEstrellas(rating) {
    const stars = starsContainer.querySelectorAll('.star');
    
    stars.forEach((star, index) => {
        const svg = star.querySelector('svg');
        if (index < rating) {
            svg.setAttribute('fill', '#ffd700');
        } else {
            svg.setAttribute('fill', '#ccc');
        }
    });
}

// Restaura las estrellas a la calificación seleccionada
function resetearEstrellas() {
    if (calificacionSeleccionada === 0) return;
    actualizarEstrellas();
}

// Actualiza el color de las estrellas según la calificación seleccionada
function actualizarEstrellas() {
    const stars = starsContainer.querySelectorAll('.star');
    
    stars.forEach((star, index) => {
        const svg = star.querySelector('svg');
        if (index < calificacionSeleccionada) {
            svg.setAttribute('fill', '#ffd700');
        } else {
            svg.setAttribute('fill', '#ccc');
        }
    });
}

// Guarda la calificación y muestra un mensaje
function guardarCalificacion() {
    if (calificacionSeleccionada === 0) {
        alert('Por favor selecciona una calificación');
        return;
    }
    
    peliculaActual.calificacion = calificacionSeleccionada;
    alert(`¡Gracias por calificar "${peliculaActual.titulo}" con ${calificacionSeleccionada} estrella(s)!`);
    cerrarModal();
}

// Función para cargar las estrellas de calificación
function cargarEstrellas() {
    starsContainer.innerHTML = '';
    
    // Crear 5 estrellas SVG
    for (let i = 1; i <= 5; i++) {
        const star = document.createElement('div');
        star.className = 'star';
        star.dataset.rating = i;
        
        star.innerHTML = `
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="${i <= peliculaActual.calificacion ? '#ffd700' : '#ccc'}">
                <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"/>
            </svg>
        `;
        
        star.addEventListener('click', () => seleccionarCalificacion(i));
        star.addEventListener('mouseover', () => resaltarEstrellas(i));
        star.addEventListener('mouseout', () => resetearEstrellas());
        
        starsContainer.appendChild(star);
    }
}

// Función para seleccionar una calificación
function seleccionarCalificacion(rating) {
    calificacionSeleccionada = rating;
    actualizarEstrellas();
}

// Función para resaltar estrellas al pasar el mouse
function resaltarEstrellas(rating) {
    const stars = starsContainer.querySelectorAll('.star');
    
    stars.forEach((star, index) => {
        const svg = star.querySelector('svg');
        if (index < rating) {
            svg.setAttribute('fill', '#ffd700');
        }
    });
}

// Función para resetear estrellas al quitar el mouse
function resetearEstrellas() {
    if (calificacionSeleccionada === 0) return;
    actualizarEstrellas();
}

// Función para actualizar el color de las estrellas
function actualizarEstrellas() {
    const stars = starsContainer.querySelectorAll('.star');
    
    stars.forEach((star, index) => {
        const svg = star.querySelector('svg');
        if (index < calificacionSeleccionada) {
            svg.setAttribute('fill', '#ffd700');
        } else {
            svg.setAttribute('fill', '#ccc');
        }
    });
}

// Función para guardar la calificación
function guardarCalificacion() {
    if (calificacionSeleccionada === 0) {
        alert('Por favor selecciona una calificación');
        return;
    }
    
    peliculaActual.calificacion = calificacionSeleccionada;
    alert(`¡Gracias por calificar "${peliculaActual.titulo}" con ${calificacionSeleccionada} estrella(s)!`);
    cerrarModal();
}